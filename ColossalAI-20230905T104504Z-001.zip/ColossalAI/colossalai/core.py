#!/usr/bin/env python
# -*- encoding: utf-8 -*-

from colossalai.context.parallel_context import global_context

__all__ = ['global_context']
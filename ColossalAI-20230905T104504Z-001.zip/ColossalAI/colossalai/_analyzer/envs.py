from dataclasses import dataclass


@dataclass
class MeshConfig:
    TFLOPS: float = 1.9e12
    BANDWIDTH = 1.2e9

from .lazy_init import LazyInitContext, LazyTensor

__all__ = [
    'LazyInitContext',
    'LazyTensor',
]

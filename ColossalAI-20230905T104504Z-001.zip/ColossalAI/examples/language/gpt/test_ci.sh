set -x
cd gemini && bash test_ci.sh

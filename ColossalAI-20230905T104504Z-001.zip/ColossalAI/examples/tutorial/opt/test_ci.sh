#!/bin/bash

cd opt && bash test_ci.sh

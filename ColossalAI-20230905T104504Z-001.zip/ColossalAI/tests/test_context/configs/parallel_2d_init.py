#!/usr/bin/env python
# -*- encoding: utf-8 -*-

parallel = dict(
    pipeline=dict(size=2),
    tensor=dict(
        size=4,
        mode='2d'
    )
)
